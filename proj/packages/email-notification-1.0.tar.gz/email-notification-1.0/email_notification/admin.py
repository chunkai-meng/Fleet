from django.contrib import admin
from .forms import TemplateForm
from .models import Template, EmailNotification
from django.db import models
from django.forms.widgets import TextInput
from django.utils.safestring import mark_safe


class EmailNotificationAdmin(admin.ModelAdmin):
    list_display = ('id', 'email_template', 'email_to',
                    'subject_value1', 'subject_value2',
                    'notification_from', 'notification_to_group',
                    )
    filter_horizontal = ('notification_to',)
    fieldsets = (
        ('Common Info', {
            'fields': (
                'if_email_notify', 'email_to',
                'notification_from', 'notification_to', 'notification_to_group')
        }),
        ('Web message (Optional)', {
            'fields': ('notification_title', 'notification_message', 'valid_days', 'if_read')
        }),
        ('Email message', {
            'fields': (
                'email_template', 'template_body',
                'subject_value1', 'subject_value2', 'subject_value3', 'subject_value4',
                'body_value1', 'body_value2', 'body_value3', 'body_value4', 'body_value5', 'body_value6')
        })
    )
    readonly_fields = ['template_body']
    formfield_overrides = {
        models.TextField: {'widget': TextInput(attrs={'size': 120})},
    }

    def template_body(self, obj):
        return mark_safe(obj.email_template.html_body.format(
            obj.body_value1, obj.body_value2, obj.body_value3, obj.body_value4, obj.body_value5, obj.body_value6
        ))


class TemplateAdmin(admin.ModelAdmin):
    list_display = ('id', 'category', 'subject')
    form = TemplateForm
    # readonly_fields = ('category',)


admin.site.register(Template, TemplateAdmin)
admin.site.register(EmailNotification, EmailNotificationAdmin)
