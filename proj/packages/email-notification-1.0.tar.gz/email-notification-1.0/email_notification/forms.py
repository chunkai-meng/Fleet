from django import forms
from .models import Template


class TemplateForm(forms.ModelForm):
    class Meta:
        model = Template
        fields = '__all__'
        widgets = {
            'subject': forms.TextInput(attrs={'size': 100}),
            'description': forms.Textarea(attrs={'rows': 4, 'cols': 100}),
            'text_body': forms.Textarea(attrs={'rows': 10, 'cols': 100}),
            'html_body': forms.Textarea(attrs={'rows': 10, 'cols': 100}),
        }
