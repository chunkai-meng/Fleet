from django.dispatch import receiver
from .models import EmailNotification, EmailService

from django.db.models.signals import m2m_changed


# when QifNotification has notification_to
@receiver(m2m_changed, sender=EmailNotification.notification_to.through)
def notification_create(sender, action, pk_set, instance=None, **kwargs):
    # print('notification action:', action)
    if action in ['post_add']:
        email_obj = EmailService(instance)
        email_obj.send_notification_email()
