import requests
from django.conf import settings
from rest_framework import status
from rest_framework.response import Response
from django.core.mail import EmailMultiAlternatives


def common_notification(obj):
    qif_id = obj.id
    category = obj.get_category_display() or obj.get_event_category_display() or 'N/A'
    # date = obj.event_at and obj.event_at.strftime('%Y-%m-%d') or ''
    date = obj.submitted_at and obj.submitted_at.strftime('%d/%m/%Y') or ''
    fields = {
        "if_email_notify": True,
        "subject_value1": qif_id,
        "subject_value2": category,
        "subject_value3": date,
    }
    from .models import EmailNotification
    return EmailNotification(**fields)


def celery_send_email(msg_from, msg_to, subject, text_content, html_content, msg_id=None):
    if msg_to == '' or (text_content == '' and html_content == ''):
        return
    if hasattr(settings, 'EMAIL_CARRIER'):
        url = settings.EMAIL_CARRIER['CELERY_EMAIL_API_ENDPOINT']
        token = settings.EMAIL_CARRIER['CELERY_API_KEY']
        # url = 'http://127.0.0.1:8080/email/'
    else:
        raise ValueError('please provide EMAIL_CARRIER dict in settings')
    data = {"msg_id": msg_id,
            "from": msg_from,
            "to": msg_to,
            "subject": subject,
            "text_content": text_content,
            "html_content": html_content,
            "token": token,
            }
    try:
        result = requests.post(url, data=data)
        res = {"response": result}
        print(res)
        return Response(res, status=status.HTTP_200_OK)
    except requests.exceptions.Timeout as errt:
        res = {"error": errt}
        print(res)

        return Response(res, status=status.HTTP_408_REQUEST_TIMEOUT)
    except requests.exceptions.HTTPError as errh:
        res = {"error": errh}
        print(res)

        return Response(res, status=status.HTTP_400_BAD_REQUEST)
    except requests.exceptions.ConnectionError as errc:
        res = {"error": errc}
        print(res)

        return Response(res, status=status.HTTP_412_PRECONDITION_FAILED)
    else:
        res = {"error": "Unknown Error"}
        print(res)
        return Response(res, status=status.HTTP_400_BAD_REQUEST)


def django_send_email(email_from, email_to, subject, text_body, html_body):
    print(subject, text_body, email_from, email_to)
    msg = EmailMultiAlternatives(
        subject, text_body, email_from, email_to, reply_to=['no-reply@qif.co.nz'])
    if html_body:
        msg.attach_alternative(html_body, "text/html")
    msg.send()
