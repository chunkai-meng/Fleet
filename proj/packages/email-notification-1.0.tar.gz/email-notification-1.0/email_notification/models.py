from django.db import models
from django.conf import settings
from django.contrib.auth.models import Group
from .utils import django_send_email, celery_send_email


class Template(models.Model):
    DEFAULT_TEMPLATE_CHOICES = [
        # notify
        ('1', 'Template 1'),
        ('2', 'Template 2'),
        ('3', 'Template 3'),
        ('4', 'Template 4'),
        ('5', 'Template 5'),
        ('6', 'Template 6'),
        ('7', 'Template 7'),
        ('8', 'Template 8'),
    ]
    category = models.CharField(choices=getattr(settings, "TEMPLATE_CHOICES", DEFAULT_TEMPLATE_CHOICES),
                                max_length=128, unique=True)
    description = models.TextField(default='')
    subject = models.CharField(max_length=512, blank=True)
    text_body = models.TextField(max_length=2048, blank=True)
    html_body = models.TextField(max_length=2048, blank=True)

    def __str__(self):
        return self.category


class BaseEmail(models.Model):
    notification_from = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        blank=True, null=True, related_name='+'
    )
    notification_to = models.ManyToManyField(
        settings.AUTH_USER_MODEL, related_name="notification_set",
        blank=True,
    )
    notification_to_group = models.ForeignKey(
        Group, on_delete=models.CASCADE,
        blank=True, null=True, related_name='group_notification_set')
    notification_title = models.CharField(max_length=512, blank=True)
    notification_message = models.TextField(blank=True)
    valid_days = models.SmallIntegerField(
        default=14, help_text="Set it to 0 if don't need a site notification!")
    if_read = models.BooleanField(default=False)
    if_email_notify = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True, editable=False)

    class Meta:
        abstract = True


class EmailNotification(BaseEmail):
    email_to = models.CharField(max_length=254, blank=True, help_text='if set will ignore notification_to')
    email_template = models.ForeignKey(Template, on_delete=models.SET_NULL, null=True)
    subject_value1 = models.CharField('Subject Value1 {0}', max_length=128, blank=True)
    subject_value2 = models.CharField('Subject Value1 {1}', max_length=128, blank=True)
    subject_value3 = models.CharField('Subject Value1 {2}', max_length=128, blank=True)
    subject_value4 = models.CharField('Subject Value1 {3}', max_length=128, blank=True)
    body_value1 = models.TextField('Body Value {0}', blank=True)
    body_value2 = models.TextField('Body Value {1}', blank=True)
    body_value3 = models.TextField('Body Value {2}', blank=True)
    body_value4 = models.TextField('Body Value {3}', blank=True)
    body_value5 = models.TextField('Body Value {4}', blank=True)
    body_value6 = models.TextField('Body Value {5}', blank=True)

    def __str__(self):
        return self.notification_title

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        email = EmailService(self)
        email.send_notification_email()


class EmailService:
    def __init__(self, notification):
        if notification.if_email_notify:
            self.email_from = notification.notification_from and notification.notification_from.email
            if not self.email_from:
                self.email_from = settings.DEFAULT_FROM_EMAIL
            self.email_to = self.get_email_to_list(notification)
            self.subject = notification.email_template.subject.format(
                notification.subject_value1, notification.subject_value2,
                notification.subject_value3, notification.subject_value4,
            )
            self.text_body = notification.email_template.text_body.format(
                notification.body_value1, notification.body_value2,
                notification.body_value3, notification.body_value4,
                notification.body_value5, notification.body_value6,
            )
            self.html_body = notification.email_template.html_body.format(
                notification.body_value1, notification.body_value2,
                notification.body_value3, notification.body_value4,
                notification.body_value5, notification.body_value6,
            )

    def send_notification_email(self):
        if self.email_to:
            if hasattr(settings, 'EMAIL_CARRIER') and settings.EMAIL_CARRIER['name'] == 'celery':
                celery_send_email(self.email_from, self.email_to, self.subject, self.text_body, self.html_body)
            else:
                # django email accept email_to as a list
                django_send_email(self.email_from, self.email_to.split(','), self.subject, self.text_body,
                                  self.html_body)

    def get_email_to_list(self, notification) -> str:
        email_to = set(notification.email_to.split(','))
        # print('Start getting email:', email_to)
        if notification.notification_to.all().count() > 0:
            for to_user in notification.notification_to.all():
                if to_user.email:
                    email_to.add(to_user.email)
        # print('Start getting email:', email_to)

        if notification.notification_to_group:
            for to_user in notification.notification_to_group.user_set.all():
                if to_user.email:
                    email_to.add(to_user.email)
        # print('Start Sending email:', email_to)

        return ','.join(email_to)
