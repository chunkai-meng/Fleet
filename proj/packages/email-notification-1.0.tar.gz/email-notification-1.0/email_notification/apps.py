from django.apps import AppConfig


class EmailNotificationConfig(AppConfig):
    name = 'email_notification'
    verbose_name = '#4 - Notification Management'

    def ready(self):
        import email_notification.signals
