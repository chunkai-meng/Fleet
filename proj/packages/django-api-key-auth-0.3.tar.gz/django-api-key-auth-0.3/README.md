# Secure API Signature Mechanism

## Usage

**Step 1: Signing Algorithm**

1. Let's say we have an **Original Request url**, you can add any query parameters

   ```
   http://cas.waicloud.co/sample/key-auth/?ID=163&api_key=wms&checkout=true
   ```

2. Get the query string

   ```
   ID=163&api_key=wms&checkout=true
   ```

3.  Strip all `&` , lower case the string, and order the parameters by key in alphabetical order 

   ```
   api_key=wmscheckout=trueid=163
   ```

4. add timestamp at the end

   ```
   api_key=wmscheckout=trueid=163timestamp=20200630163323
   ```

5. Add api_secret to the end of above string
   ```python
   api_key=wmscheckout=trueid=163timestamp=20200630163323api_secret=y8xwTW81UA5x
   ```

6. md5 the above string as the sign value
   ```
   fd69ffc90d1429b029c064c1b994b370
   ```



**Step 2: Create New request url**

Add the timestamp and sign to the end of **Original url**

```python
http://cas.waicloud.co/sample/key-auth/?ID=163&api_key=wms&checkout=true&timestamp=20200630163323&sign=fd69ffc90d1429b029c064c1b994b370
```



**Note:** 

1. The time stamp must be the one you use to encrpty.
2. Add sign to the end, do **not** add `api_secret`.



## Python Sample code

```bash
python3 sign.py
```

```python
# sign.py
from hashlib import md5
from datetime import datetime


def sort_query_string(query_string):
    lower_query_string = query_string.lower()
    sorted_query_string = ''.join(sorted(lower_query_string.split('&')))
    return sorted_query_string


def sign_request(url, api_secret, timestamp=None):
    """sign a url"""
    print('original url:', url)
    timestamp = timestamp or datetime.now().strftime("%Y%m%d%H%M%S")
    if len(url.split('?')) < 2:
        return 'please provide api_key field in url query string'
    query_string = url.split('?')[1]
    sorted_query_string = sort_query_string(query_string)
    print('sorted:', sorted_query_string)
    data = sorted_query_string + "timestamp=" + timestamp + 'api_secret=' + api_secret
    print('data to sign:', data)
    sign = md5(data.encode('utf-8')).hexdigest()
    url += '&timestamp={}&sign={}'.format(timestamp, sign)
    print('request url: ', url)
    return url


url = 'http://cas.waicloud.co/sample/key-auth/?api_key=wms&checkout=true&id=163'
url = sign_request(url, 'y8xwTW81UA5x')
```



## Build Package

1. Update setup.cfg
```
version = 0.3 <to next version>
```

2. run from inside api-keys
```
python setup.py sdist
```

