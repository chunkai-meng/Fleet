from django.apps import AppConfig


class ApiKeyConfig(AppConfig):
    name = 'api_key'
