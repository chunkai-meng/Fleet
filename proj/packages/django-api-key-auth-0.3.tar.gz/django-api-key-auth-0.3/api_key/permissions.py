from django.db.models import Q
from .models import ApiKey
from rest_framework.permissions import BasePermission
from hashlib import md5
from .utils import sort_query_string
from django.utils import timezone
from datetime import datetime


def restore_request_sign(url, api_secret):
    """Retrieve Sign from url and api_secret"""

    # print('received request: ', url)
    query_string = url.split('?')[1] if '?' in url else url
    data_string = query_string.split('&sign')[0]
    # print('deleted sign: ', data_string)
    data = sort_query_string(data_string) + 'api_secret=' + api_secret
    # print('data to encode: ', data)
    sign = md5(data.encode('utf-8')).hexdigest()
    # print('should have a sign: ', sign)
    return sign


def get_client_ip(request):
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        ip = x_forwarded_for.split(',')[0]
    else:
        ip = request.META.get('REMOTE_ADDR')
    return ip


class CheckSourceIP(BasePermission):
    message = 'Your IP is not allowed'

    def has_permission(self, request, view):
        api_key = request.query_params.get('api_key')
        try:
            app_obj = ApiKey.objects.get(api_key=api_key)
            api_source = app_obj.source
        except ApiKey.DoesNotExist:
            self.message = "api key not found."
            return False

        if not api_source:
            return True

        ip_list = api_source.replace(' ', '').split(',')
        ip = get_client_ip(request)
        return ip.split('.')[0] in ip_list


class CheckApiKeySign(BasePermission):
    message = "api sign incorrect."

    def has_permission(self, request, view):
        api_key = request.query_params.get('api_key')
        query_string = request.META['QUERY_STRING']
        timestamp = request.query_params.get('timestamp')
        sign = request.query_params.get('sign')
        try:
            key = ApiKey.objects.get(api_key=api_key)
            api_secret = key.api_secret
            api_timeout_in = key.timeout_in
            api_expired_at = key.expired_at
        except ApiKey.DoesNotExist:
            self.message = "api key not found."
            return False

        # Check timeout
        if has_timeout(timestamp, api_timeout_in):
            self.message = "api request timeout, please create new timestamp for new request."
            return False

        # Check key expired
        if has_expired(api_expired_at):
            self.message = "API Key and Secret has expired."
            return False

        # print('query_string: ', query_string)
        restored_sign = restore_request_sign(query_string, api_secret)
        # print('restored sign: ', restored_sign)
        # print('if correct: ', restored_sign == sign)
        # print('Should have a sign', sign)
        # print(api_secret, api_timeout_in)
        return restored_sign == sign


class CheckApiKeyAuth(BasePermission):
    def has_permission(self, request, view):
        api_key = request.query_params.get('api_key')
        post_secret = request.query_params.get('api_secret')
        try:
            obj = ApiKey.objects.get(Q(api_key=api_key, revoked=False),
                                     Q(expired_at__isnull=True) |
                                     Q(expired_at__gt=timezone.now()))
            api_secret = obj.api_secret
        except ApiKey.DoesNotExist:
            return False

        return post_secret == api_secret


def has_timeout(timestamp, timeout_in):
    timestamp_object = datetime.strptime(timestamp, '%Y%m%d%H%M%S')
    now = timezone.now().today()
    now_unix = round(now.timestamp())
    timestamp_unix = round(timestamp_object.timestamp())
    interval = now_unix - timestamp_unix
    # print('now', now.strftime('%Y%m%d%H%M%S'), 'dest:', timestamp_object)
    # print('now', now_unix, 'dest:', timestamp_unix)
    # print(interval, timeout_in)
    return interval > timeout_in


def has_expired(expired_at):
    if expired_at and isinstance(expired_at, datetime):
        now = timezone.now()
        return now > expired_at
    else:
        return False
