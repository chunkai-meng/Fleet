from hashlib import md5
from datetime import datetime


def sort_query_string(query_string):
    lower_query_string = query_string.lower()
    sorted_query_string = ''.join(sorted(lower_query_string.split('&')))
    return sorted_query_string


def sign_request(url, api_secret, timestamp=None):
    """sign a url"""
    # print('original url:', url)
    timestamp = timestamp or datetime.now().strftime("%Y%m%d%H%M%S")
    if len(url.split('?')) < 2:
        return 'please provide api_key field in url query string'
    query_string = url.split('?')[1]
    sorted_query_string = sort_query_string(query_string)
    # print('sorted:', sorted_query_string)
    data = sorted_query_string + "timestamp=" + timestamp + 'api_secret=' + api_secret
    # print('data to sign:', data)
    sign = md5(data.encode('utf-8')).hexdigest()
    url += '&timestamp={}&sign={}'.format(timestamp, sign)
    # print('request url: ', url)
    return url
